"use client";
import { useState, useEffect } from "react";

const FEATURED_VENUES = [
  { name:"LoCali Wine Lounge", tag:"Live music Wed–Sun • Wine lounge", description:"Downtown West Chester's California-inspired wine lounge, intentionally built as a listening-friendly room where the music comes first. Weekly LoCali Live and Friday Hang acoustic sets, Sunday Songs, Songwriter Circles, open mics, vinyl nights, and Golden Hour happy hour daily 4–6pm.", address:"123 E Market St, West Chester, PA 19382", scheduleUrl:"https://www.enjoylocali.com/events", website:"https://www.enjoylocali.com", openTable:null, instagram:"https://www.instagram.com/locali_westchester/", color:"#9d174d" },
  { name:"Pietro's Prime", tag:"Live music Wed–Sat", description:"West Chester's premier upscale steakhouse with exceptional cuisine, the best martinis in town, and live entertainment every Wednesday through Saturday night.", address:"125 West Market St, West Chester, PA 19382", scheduleUrl:"https://www.facebook.com/pietrosprimewc", website:"https://www.pietrosprime.com", openTable:"https://www.opentable.com/pietros-prime", instagram:"https://www.instagram.com/pietrosprime/", color:"#e85d04" },
  { name:"Station 142", tag:"Live music Thurs–Sat", description:"West Chester's premier live music venue featuring an intimate stage, state-of-the-art sound system, two full bars, rooftop dining, and top local and regional acts.", address:"142 E Market St, West Chester, PA 19382", scheduleUrl:"https://station142.com/live-music/", website:"https://station142.com", openTable:null, instagram:"https://www.instagram.com/station.142/", color:"#1a0a00" },
  { name:"Brickette Lounge", tag:"Live music & events • 21+", description:"West Chester's lively neighborhood bar featuring live music, events, and a full BBQ menu on weekends. Bar open daily 12pm–2am. 21+ after 5pm.", address:"3 W Gay St, West Chester, PA 19380", scheduleUrl:"https://www.brickettelounge.com/music-events", website:"https://www.brickettelounge.com", openTable:null, instagram:"https://www.instagram.com/brickettelounge/", color:"#7c3aed" },
  { name:"Slow Hand Food & Drink", tag:"Live music & events", description:"West Chester's upscale American comfort restaurant in a historic firehouse, hosting live performances from local bands and solo artists alongside scratch-made food and award-winning cocktails.", address:"30 N Church St, West Chester, PA 19380", scheduleUrl:"https://www.slowhand-wc.com/events", website:"https://www.slowhand-wc.com", openTable:"https://www.opentable.com/slow-hand-food-and-drink", instagram:"https://www.instagram.com/slowhandwc/", color:"#0f766e" },
  { name:"Square Bar", tag:"Live music • Open since 1950s", description:"West Chester's beloved dive bar for 70+ years featuring live music, games, sports, and great company. A true neighborhood institution at 250 E Chestnut St.", address:"250 E Chestnut St, West Chester, PA 19380", scheduleUrl:"https://www.squarebarwc.com/events", website:"https://www.squarebarwc.com", openTable:null, instagram:"https://www.instagram.com/squarebarwc/", color:"#b45309" },
  { name:"Saloon 151", tag:"Karaoke • Music Bingo • Events", description:"West Chester's best whiskey and bourbon bar featuring karaoke every Friday, Music Bingo Wednesdays, Quizzo Tuesdays, and country party vibes nightly. Open 11am–2am daily.", address:"151 W Gay St, West Chester, PA 19380", scheduleUrl:"https://www.saloon151.com/events-catering-1", website:"https://www.saloon151.com", openTable:null, instagram:"https://www.instagram.com/saloon151/", color:"#92400e" },
  { name:"Murph's Hideaway", tag:"Local favorite • Live music & events", description:"A welcoming neighborhood spot offering great food, drinks, and live music entertainment. Popular with locals for its friendly atmosphere and quality performances.", address:"Pocono Lake, PA 18347", scheduleUrl:"https://www.murphshideaway.com", website:"https://www.murphshideaway.com", openTable:null, instagram:null, color:"#059669" },
  { name:"Nick's Lakehouse", tag:"Lakeside bar & live music", description:"A beloved Pocono Lakes area bar and grill right on the water, featuring live music, great food, cold drinks, and an unbeatable lakeside atmosphere that keeps locals coming back all summer long.", address:"Pocono Lake, PA 18347", scheduleUrl:"https://www.nickslakehouse.com", website:"https://www.nickslakehouse.com", openTable:null, instagram:null, color:"#0369a1" },
  { name:"Boulder View Tavern", tag:"Pocono staple • Live music & events", description:"A Pocono Mountains institution serving hearty food and cold drinks with regular live music events. Known for its friendly crowd, rustic atmosphere, and being a true gathering place for the local community.", address:"Pocono Lake, PA 18347", scheduleUrl:"https://www.boulderviewtavern.com", website:"https://www.boulderviewtavern.com", openTable:null, instagram:null, color:"#78350f" },
  { name:"Jubilee", tag:"Live music & dining • Pocono", description:"A popular Pocono area destination for live music, great food, and a lively atmosphere. Jubilee brings together locals and visitors for memorable nights of entertainment in the heart of the mountains.", address:"Pocono Lake, PA 18347", scheduleUrl:"https://www.jubileepoconos.com", website:"https://www.jubileepoconos.com", openTable:null, instagram:null, color:"#7c3aed" },
  { name:"Commodore John Barry Arts & Cultural Center", tag:"Irish & Celtic music • Philadelphia", description:"Philadelphia's premier Irish cultural venue at 6815 Emlen Street in Mt. Airy, hosting world-class Irish and Celtic performers, concerts, traditional music sessions, and cultural events open to the public year-round.", address:"6815 Emlen Street, Philadelphia, PA 19119", scheduleUrl:"https://theirishcenter.org/irish-center-events-calendar/", website:"https://theirishcenter.org/irish-center-events-calendar/", openTable:null, instagram:"https://www.instagram.com/irishcenterphila/", color:"#166534" },
  { name:"Bubb City", tag:"Chicago's country & live music hotspot", description:"Chicago's premier country music bar and concert venue, featuring live bands and top-tier entertainment in the heart of the city. Bubb City draws big crowds for its honky-tonk vibes, great drinks, and world-class performances.", address:"435 N Dearborn St, Chicago, IL 60654", scheduleUrl:"https://www.hubbardinn.com", website:"https://www.bubbcity.com", openTable:null, instagram:"https://www.instagram.com/bubbcitychicago/", color:"#b45309" },
];

const WC_ZIPS = ["19380","19381","19382","19383","18347","19119","pocono lake","west chester","westchester","chicago","philadelphia"];
const isWC = (q) => q && WC_ZIPS.some(z => q.toLowerCase().includes(z));

// Returns true if at least one FEATURED_VENUE matches this quick-pick location
const quickHasFeaturedVenue = (sq) => {
  const sl = sq.toLowerCase();
  return FEATURED_VENUES.some(v => {
    const al = v.address.toLowerCase();
    if (sl.includes("19382") || sl.includes("west chester")) return al.includes("19382") || al.includes("west chester");
    if (sl.includes("18347") || sl.includes("pocono lake")) return al.includes("18347") || al.includes("pocono lake");
    if (sl.includes("chicago")) return al.includes("chicago");
    if (sl.includes("19119") || sl.includes("philadelphia")) return al.includes("19119") || al.includes("philadelphia");
    return false;
  });
};
const FEATURED_BANDS = [
  { name: "Nathan Carter", genre: "Irish Country", instagram: "https://www.instagram.com/nathancartermusic/", bandsintown: "https://www.bandsintown.com/a/nathan-carter", website: "https://www.nathancartermusic.com" },
];

const DATE_FILTERS = ["Today","This Weekend","Next 7 Days","Next 3 Months","Next 6 Months"];
const RADIUS_OPTIONS = [5,10,20,50];
const QUICK = ["19382 (West Chester)","18347 (Pocono Lake)","19119 (Philadelphia)","Sea Isle, NJ","Kennett Square, PA","Malvern, PA","Phoenixville, PA","Los Angeles, CA","Chicago, IL","Miami, FL","Dallas, TX","Seattle, WA"];
const CULTURES = [
  { label: "🍀 Irish / Celtic", value: "Irish and Celtic", venues: ["Commodore John Barry Arts & Cultural Center (Philadelphia, PA)", "The Irish Pub (Philadelphia, PA)", "Rí Rá Irish Pub (multiple cities)", "Fado Irish Pub (multiple cities)", "The Plough and the Stars (San Francisco, CA)", "Celtic Junction Arts Center (St. Paul, MN)", "The Burren (Somerville, MA)"] },
  { label: "💃 Latin / Salsa", value: "Latin and Salsa", venues: ["Guantanamera (New York, NY)", "SOBs Sounds of Brazil (New York, NY)", "Cafe La Trova (Miami, FL)", "La Descarga (Los Angeles, CA)", "Havana Social Club (Chicago, IL)", "Salsa Con Fuego (Philadelphia, PA)", "Cascabel (Houston, TX)"] },
  { label: "🎷 Jazz", value: "Jazz", venues: ["Blue Note Jazz Club (New York, NY)", "Jazz at Lincoln Center (New York, NY)", "Green Mill (Chicago, IL)", "Preservation Hall (New Orleans, LA)", "The Jazz Kitchen (Indianapolis, IN)", "Scullers Jazz Club (Boston, MA)", "Chris Jazz Cafe (Philadelphia, PA)", "Dimitriou's Jazz Alley (Seattle, WA)"] },
  { label: "🎸 Blues", value: "Blues", venues: ["Buddy Guy's Legends (Chicago, IL)", "Antone's (Austin, TX)", "Ground Zero Blues Club (Clarksdale, MS)", "Blues City Deli (St. Louis, MO)", "The Rum Boogie Cafe (Memphis, TN)", "B.B. King's Blues Club (Memphis, TN)", "Tin Pan South venues (Nashville, TN)"] },
  { label: "🤠 Bluegrass / Americana", value: "Bluegrass and Americana", venues: ["Station Inn (Nashville, TN)", "The Birchmere (Alexandria, VA)", "World Cafe Live (Philadelphia, PA)", "The Bluebird Cafe (Nashville, TN)", "Appalachian Power Company (Fayetteville, WV)", "Merlefest (Wilkesboro, NC)", "Grey Fox Bluegrass Festival (Oak Hill, NY)"] },
  { label: "🙏 Gospel", value: "Gospel and Gospel Soul", venues: ["Abyssinian Baptist Church (New York, NY)", "Greater St. Stephen Full Gospel Church (New Orleans, LA)", "Trinity United Church of Christ (Chicago, IL)", "Ben Hill United Methodist Church (Atlanta, GA)", "St. Augustine's Catholic Church (New Orleans, LA)", "West Angeles Church of God in Christ (Los Angeles, CA)"] },
  { label: "🌴 Reggae", value: "Reggae", venues: ["Negril Village (New York, NY)", "The Reggae Lounge (Miami, FL)", "Riddims (Atlanta, GA)", "Ackee Bamboo Jamaican Cuisine (Chicago, IL)", "The Rasta Bar (Los Angeles, CA)", "Reggae on the River (Humboldt County, CA)", "Island Noodles (Philadelphia, PA)"] },
  { label: "🪗 Cajun / Zydeco", value: "Cajun and Zydeco", venues: ["Tipitina's (New Orleans, LA)", "Rock 'n' Bowl (New Orleans, LA)", "Maple Leaf Bar (New Orleans, LA)", "Cafe des Amis (Breaux Bridge, LA)", "Richard's Club (Lawtell, LA)", "Mid-City Lanes Rock 'n' Bowl (New Orleans, LA)"] },
  { label: "💃 Flamenco", value: "Flamenco", venues: ["Tablao Flamenco (Chicago, IL)", "Casa Flamenca (Albuquerque, NM)", "La Peña Cultural Center (Berkeley, CA)", "Gitano (New York, NY)", "El Flamenco Live (Miami, FL)", "Museo del Barrio (New York, NY)"] },
  { label: "🎶 Indian / Bollywood", value: "Indian Classical and Bollywood", venues: ["India Cultural Center (multiple cities)", "Baroda Restaurant (Philadelphia, PA)", "Asha Bhosle Concert venues", "Mirage Banquet Hall (Chicago, IL)", "Bollywood Groove venues (Seattle, WA)", "India House (Houston, TX)", "South Asian Arts (San Francisco, CA)"] },
  { label: "🥁 Afrobeat", value: "Afrobeat", venues: ["SOBs Sounds of Brazil (New York, NY)", "Afro Lounge (Atlanta, GA)", "The Shrine (New York, NY)", "African Cultural Center (Philadelphia, PA)", "Afrikiko Riverside Restaurant (Houston, TX)", "Calabar Imports (Chicago, IL)", "Mama Africa (Washington, DC)"] },
  { label: "🎻 Klezmer / Jewish", value: "Klezmer and Jewish music", venues: ["Yiddish New York venues", "Workmen's Circle (New York, NY)", "KlezKanada (Montreal, QC)", "Philadelphia Klezmer Project venues", "Idelsohn Society venues", "92nd Street Y (New York, NY)", "The Fringe Bar (Philadelphia, PA)"] },
  { label: "🫒 Greek / Mediterranean", value: "Greek and Mediterranean", venues: ["Taverna Opa (multiple cities)", "Zorba's (Philadelphia, PA)", "Greek American Social Club venues", "Hellenic Center (Chicago, IL)", "Estiatorio Milos (New York, NY)", "Santorini by Georgios (Atlanta, GA)", "Mediterranean Festival venues"] },
  { label: "🎤 Hip-Hop / R&B", value: "Hip-Hop and R&B", venues: ["Apollo Theater (New York, NY)", "Howard Theatre (Washington, DC)", "The Fillmore (multiple cities)", "The Peppermint Club (Los Angeles, CA)", "City Winery (multiple cities)", "The Met Philadelphia (Philadelphia, PA)", "House of Blues (multiple cities)"] },
];
const SYSTEM_PROMPT = `You are a live music event finder. Find live music events near the exact location given. Return ONLY a JSON array with up to 6 results. Each item: { band, venue, date, time, genre, address, tickets, notes, venueBio, bandBio, confidence }. confidence is "high" or "medium". Never return Unknown. Never default to West Chester PA unless asked. Do NOT include Pietro's Prime or Station 142. Return ONLY valid JSON.`;

// venue name → URL-safe key: "Pietro's Prime" → "pietros-prime"
const toVibeKey = (name) => name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");

// venue name → Instagram keyword search URL
const toIgUrl = (name) => `https://www.instagram.com/explore/search/keyword/?q=${encodeURIComponent(name)}`;

// Add UTM tracking to any URL
const withUTM = (url, venue) =>
  `${url}${url.includes("?") ? "&" : "?"}utm_source=locallivemusic&utm_medium=app&utm_campaign=reserve&utm_content=${encodeURIComponent(venue)}`;

// Fire GA event when Reserve is clicked
const trackReserve = (venueName) => {
  if (typeof window !== "undefined" && window.gtag) {
    window.gtag("event", "reserve_click", {
      event_category: "engagement",
      event_label: venueName,
    });
  }
};

const timeAgo = (ts) => {
  const mins = Math.floor((Date.now() - ts) / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  return `${Math.floor(mins / 60)}h ago`;
};

const VIBE_LABELS = ["", "Dead in here", "It's quiet", "Getting going", "Good vibe!", "🔥 Absolutely packed!"];

// ── Star component ────────────────────────────────────────────────────────
const Stars = ({ count, interactive, onSelect, hovered, onHover, size }) => (
  <span style={{ display: "inline-flex", gap: 1, cursor: interactive ? "pointer" : "default" }}>
    {[1,2,3,4,5].map(i => (
      <span key={i}
        style={{ fontSize: size || (interactive ? 24 : 13), lineHeight: 1, opacity: i <= (hovered || count) ? 1 : 0.25, transition: "opacity 0.1s" }}
        onClick={() => interactive && onSelect && onSelect(i)}
        onMouseEnter={() => interactive && onHover && onHover(i)}
        onMouseLeave={() => interactive && onHover && onHover(0)}>
        ⭐
      </span>
    ))}
  </span>
);

// ── Single vibe post ──────────────────────────────────────────────────────
const VibePost = ({ vibe, isFirst }) => (
  <div style={{ display: "flex", alignItems: "flex-start", gap: 10, padding: "10px 0", borderTop: isFirst ? "none" : "1px solid #f1f5f9" }}>
    <Stars count={vibe.stars} interactive={false} hovered={0} size={13} />
    <div style={{ flex: 1, minWidth: 0 }}>
      {vibe.comment && <p style={{ fontSize: 12, color: "#0f172a", margin: "0 0 3px", lineHeight: 1.4, fontStyle: "italic" }}>"{vibe.comment}"</p>}
      <p style={{ fontSize: 10, color: "#94a3b8", margin: 0 }}>{timeAgo(vibe.postedAt)}</p>
    </div>
  </div>
);

// ── Vibe input form ───────────────────────────────────────────────────────
const VibeForm = ({ venueKey, venueName, onSubmit, onCancel }) => {
  const [stars, setStars] = useState(0);
  const [hovered, setHovered] = useState(0);
  const [comment, setComment] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  const submit = async () => {
    if (!stars) { setError("Pick a star rating first"); return; }
    setSubmitting(true); setError("");
    try {
      const res = await fetch("/api/vibe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ venueKey, stars, comment }),
      });
      const data = await res.json();
      if (data.error) { setError(data.error); setSubmitting(false); return; }
      onSubmit(data.vibe);
    } catch { setError("Something went wrong, try again"); setSubmitting(false); }
  };

  return (
    <div style={{ padding: "12px 14px", borderTop: "1px solid #f1f5f9", background: "white" }}>
      <p style={{ fontSize: 11, fontWeight: 600, color: "#64748b", margin: "0 0 10px" }}>What's happening right now?</p>
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
        <Stars count={stars} interactive={true} onSelect={setStars} hovered={hovered} onHover={setHovered} />
        {(hovered || stars) > 0 && <span style={{ fontSize: 12, color: "#e85d04", fontWeight: 500 }}>{VIBE_LABELS[hovered || stars]}</span>}
      </div>
      <input
        value={comment}
        onChange={e => setComment(e.target.value.slice(0, 120))}
        placeholder="What's happening? (optional)"
        style={{ width: "100%", fontSize: 12, padding: "7px 10px", borderRadius: 8, border: "1px solid #e2e8f0", outline: "none", boxSizing: "border-box", marginBottom: 8 }}
      />
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <p style={{ fontSize: 10, color: "#94a3b8", margin: 0 }}>Visible for 1 hour · {120 - comment.length} chars left</p>
        <div style={{ display: "flex", gap: 6 }}>
          <button onClick={onCancel} style={{ fontSize: 11, padding: "5px 12px", borderRadius: 8, background: "transparent", color: "#94a3b8", border: "1px solid #e2e8f0", cursor: "pointer" }}>
            Cancel
          </button>
          <button onClick={submit} disabled={submitting || !stars}
            style={{ fontSize: 11, padding: "5px 14px", borderRadius: 8, background: submitting || !stars ? "#e2e8f0" : "#e85d04", color: submitting || !stars ? "#94a3b8" : "#fff", border: "none", cursor: submitting || !stars ? "default" : "pointer", fontWeight: 600 }}>
            {submitting ? "Posting…" : "Post Vibe"}
          </button>
        </div>
      </div>
      {error && <p style={{ fontSize: 11, color: "#dc2626", margin: "6px 0 0" }}>{error}</p>}
    </div>
  );
};

// ── Full vibe section ─────────────────────────────────────────────────────
const VibeSection = ({ venueName, allVibes, instagram }) => {
  const venueKey = toVibeKey(venueName);
  const igUrl = instagram || toIgUrl(venueName);
  const [showForm, setShowForm] = useState(false);
  const [localVibes, setLocalVibes] = useState([]);

  const serverVibes = allVibes[venueKey] || [];
  const merged = [...serverVibes];
  localVibes.forEach(lv => { if (!merged.find(sv => sv.postedAt === lv.postedAt)) merged.push(lv); });
  const currentVibes = merged.sort((a, b) => b.postedAt - a.postedAt);

  const handleSubmit = (vibe) => { setLocalVibes(prev => [...prev, vibe]); setShowForm(false); };

  return (
    <div style={{ marginTop: 12, borderRadius: 12, overflow: "hidden", border: "1px solid #e2e8f0" }}>
      {/* Orange header */}
      <div style={{ background: "#e85d04", padding: "9px 14px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <span style={{ fontSize: 14 }}>🔥</span>
          <span style={{ color: "white", fontSize: 11, fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.5px" }}>Live Vibe</span>
          {currentVibes.length > 0 && (
            <span style={{ background: "rgba(255,255,255,0.25)", color: "white", fontSize: 10, padding: "2px 8px", borderRadius: 99 }}>
              {currentVibes.length} in the last hour
            </span>
          )}
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          {/* Instagram photos link — uses venue's IG account if known, otherwise keyword search */}
          <a href={igUrl} target="_blank" rel="noreferrer"
            style={{ color: "rgba(255,255,255,0.9)", fontSize: 11, textDecoration: "none", fontWeight: 500 }}>
            📸 Photos
          </a>
          {!showForm && (
            <button onClick={() => setShowForm(true)}
              style={{ background: "white", color: "#e85d04", border: "none", borderRadius: 99, fontSize: 11, fontWeight: 600, padding: "3px 10px", cursor: "pointer" }}>
              + Share
            </button>
          )}
        </div>
      </div>
      {/* Posts */}
      {currentVibes.length > 0 && (
        <div style={{ background: "white", padding: "0 14px" }}>
          {currentVibes.map((v, i) => <VibePost key={v.postedAt} vibe={v} isFirst={i === 0} />)}
        </div>
      )}
      {/* Empty state */}
      {currentVibes.length === 0 && !showForm && (
        <div style={{ background: "white", padding: "10px 14px", display: "flex", alignItems: "center", gap: 8 }}>
          <span style={{ fontSize: 14, opacity: 0.4 }}>💬</span>
          <p style={{ fontSize: 11, color: "#94a3b8", margin: 0, fontStyle: "italic" }}>No reports yet — be the first to share the vibe!</p>
        </div>
      )}
      {/* Form */}
      {showForm && <VibeForm venueKey={venueKey} venueName={venueName} onSubmit={handleSubmit} onCancel={() => setShowForm(false)} />}
    </div>
  );
};

export default function App() {
  const [query, setQuery] = useState("");

  // Inject Google Analytics GA4 + Google AdSense + page metadata
  useEffect(() => {
    document.title = "BBK Music Seeker — Find Live Music Near You";
  }, []);
  const [activeQuick, setActiveQuick] = useState("");
  const [dateFilter, setDateFilter] = useState("Next 7 Days");
  const [radius, setRadius] = useState(10);
  const [cultures, setCultures] = useState([]);
  const [bandSearch, setBandSearch] = useState("");
  const [showContactForm, setShowContactForm] = useState(false);
  const [contactName, setContactName] = useState("");
  const [contactEmail, setContactEmail] = useState("");
  const [contactBand, setContactBand] = useState("");
  const [contactMsg, setContactMsg] = useState("");
  const [contactSent, setContactSent] = useState(false);
  const [showVenueForm, setShowVenueForm] = useState(false);
  const [venueName, setVenueName] = useState("");
  const [venueContactName, setVenueContactName] = useState("");
  const [venueContactEmail, setVenueContactEmail] = useState("");
  const [venueAddress, setVenueAddress] = useState("");
  const [venueWebsite, setVenueWebsite] = useState("");
  const [venueMsg, setVenueMsg] = useState("");
  const [venueSent, setVenueSent] = useState(false);
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [locating, setLocating] = useState(false);
  const [error, setError] = useState("");
  const [searched, setSearched] = useState("");
  const [expanded, setExpanded] = useState(null);
  const [showFeatured, setShowFeatured] = useState(false);
  const [localVenues, setLocalVenues] = useState(null);
  const [localLoading, setLocalLoading] = useState(false);
  const [localError, setLocalError] = useState("");
  const [venueSchedules, setVenueSchedules] = useState({});
  const [loadingSchedule, setLoadingSchedule] = useState(null);
  const [allVibes, setAllVibes] = useState({});

  // Fetch all vibes on mount and every 60 seconds
  useEffect(() => {
    const fetchVibes = async () => {
      try {
        const res = await fetch("/api/vibe?all=true");
        const data = await res.json();
        if (data.vibes) setAllVibes(data.vibes);
      } catch {}
    };
    fetchVibes();
    const interval = setInterval(fetchVibes, 60000);
    return () => clearInterval(interval);
  }, []);

  const getDateRange = (f) => {
    const d = new Date();
    const day = d.toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric", year: "numeric" });
    if (f === "Today") return `today only, ${day}`;
    if (f === "This Weekend") return `this weekend (Saturday and Sunday)`;
    if (f === "Next 3 Months") return `the next 3 months starting ${day} — include upcoming concerts, shows, and events`;
    if (f === "Next 6 Months") return `the next 6 months starting ${day} — include upcoming concerts, shows, and events`;
    return `the next 7 days starting ${day}`;
  };

  const findLocalVenues = async (loc, r) => {
    if (!loc) return;
    setLocalLoading(true); setLocalError(""); setLocalVenues(null);
    try {
      const res = await fetch("/api/venues", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ location: loc, radius: r || radius }) });
      const data = await res.json();
      if (data.error) { setLocalError(data.error.message); return; }
      setLocalVenues(data.venues);
    } catch (e) { setLocalError(e.message); }
    finally { setLocalLoading(false); }
  };

  const loadKnownSchedule = async (venue) => {
    const key = venue.website || venue.name;
    if (venueSchedules[key]) return;
    try {
      const res = await fetch("/api/schedule", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ venueName: venue.name, venueAddress: venue.address, venueWebsite: venue.website, findPerformers: false }),
      });
      const data = await res.json();
      if (data.schedule && data.schedule.length > 0) setVenueSchedules(prev => ({ ...prev, [key]: data }));
    } catch {}
  };

  useEffect(() => { if (showFeatured) FEATURED_VENUES.forEach(v => loadKnownSchedule(v)); }, [showFeatured]);
  useEffect(() => { if (localVenues) localVenues.forEach(v => loadKnownSchedule(v)); }, [localVenues]);

  const findPerformers = async (venue) => {
    const key = venue.website || venue.name;
    if (loadingSchedule === key) return;
    setLoadingSchedule(key);
    try {
      const res = await fetch("/api/schedule", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ venueName: venue.name, venueAddress: venue.address, venueWebsite: venue.website, findPerformers: true }),
      });
      const data = await res.json();
      setVenueSchedules(prev => ({ ...prev, [key]: { schedule: data.schedule || [], source: data.source || "none", days: data.days } }));
    } catch {
      setVenueSchedules(prev => ({ ...prev, [key]: { schedule: [], source: "error" } }));
    } finally { setLoadingSchedule(null); }
  };

  const filterSchedule = (schedule, filter) => {
    const hasSpecificDates = schedule.some(e => /\d{1,2}/.test((e.day || "") + (e.date || "")));
    if (!hasSpecificDates) return schedule;
    const now = new Date(); now.setHours(0, 0, 0, 0);
    const end = new Date(now);
    if (filter === "Today") { end.setHours(23, 59, 59); }
    else if (filter === "This Weekend") { const d = now.getDay(); end.setDate(now.getDate() + (d === 6 ? 1 : 7 - d)); end.setHours(23, 59, 59); }
    else { end.setDate(now.getDate() + 7); }
    return schedule.filter(e => {
      const ds = e.date || e.day || ""; if (!ds) return true;
      const p = new Date(ds + " 2026"); if (isNaN(p)) return true;
      p.setHours(0, 0, 0, 0);
      if (filter === "Today") return p.getTime() === now.getTime();
      if (filter === "This Weekend") return (p.getDay() === 6 || p.getDay() === 0) && p >= now && p <= end;
      return p >= now && p <= end;
    });
  };

  const search = async (q) => {
    const sq = (q || query).trim();
    if (!sq) return;
    setLoading(true); setError(""); setResults(null); setSearched(sq); setExpanded(null);
    setLocalVenues(null); setLocalError(""); setVenueSchedules({});
    const wc = isWC(sq);
    setShowFeatured(wc);
    findLocalVenues(sq, radius);
    if (wc) { setResults([]); setLoading(false); return; }
    try {
      const res = await fetch("/api/search", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ system: SYSTEM_PROMPT, messages: [{ role: "user", content: `Find live music near: "${sq}" for ${getDateRange(dateFilter)}.${bandSearch.trim() ? ` Search specifically for performances by or events featuring "${bandSearch.trim()}".` : ``}${cultures.length > 0 ? " Focus specifically on " + cultures.join(" and ") + " music and cultural venues. Known cultural venues for this style include: " + CULTURES.filter(c => cultures.includes(c.value)).flatMap(c => c.venues).join(", ") + " — prioritize these and similar venues in or near the searched location." : ""}` }] }) });
      const data = await res.json();
      if (data.error) { setError(data.error.message); return; }
      const tb = data.content?.find(b => b.type === "text");
      if (!tb) { setError("No response."); return; }
      setResults(JSON.parse(tb.text.trim().replace(/```json|```/g, "").trim()));
    } catch (e) { setError(e.message); }
    finally { setLoading(false); }
  };

  const useLocation = () => {
    setLocating(true);
    navigator.geolocation.getCurrentPosition(async (pos) => {
      try {
        const res = await fetch(`https://nominatim.openstreetmap.org/reverse?lat=${pos.coords.latitude}&lon=${pos.coords.longitude}&format=json`);
        const data = await res.json();
        const a = data.address;
        const loc = `${a.city || a.town || a.village || a.county}, ${a.state}`;
        setQuery(loc); setLocating(false); search(loc);
      } catch { setLocating(false); }
    }, () => { setError("Location access denied."); setLocating(false); });
  };

  const btn = (active) => ({ fontSize: 12, padding: "5px 14px", borderRadius: 99, border: `1.5px solid ${active ? "#e85d04" : "#e2e8f0"}`, background: active ? "#e85d04" : "transparent", color: active ? "#fff" : "#64748b", cursor: "pointer", fontWeight: active ? 600 : 400 });
  const gc = (g) => ({ "Rock": "#e85d04", "Jazz": "#1D9E75", "Country": "#BA7517", "Pop": "#D4537E", "Blues": "#378ADD", "Cover Band": "#888780", "Folk": "#639922", "R&B": "#D85a30", "Acoustic": "#0F6E56", "Indie": "#7F77DD" })[g] || "#e85d04";

  const ScheduleBlock = ({ schedData, isLoading, websiteUrl, isFeatured }) => {
    if (isLoading) return <p style={{ fontSize: 12, color: "#94a3b8", margin: "8px 0 0" }}>🔍 Searching for current performers…</p>;
    if (!schedData || schedData.schedule.length === 0) return null;
    const filtered = filterSchedule(schedData.schedule, dateFilter);
    if (filtered.length === 0) return null;
    const sourceLabel = schedData.source === "web_search" ? "📅 Found via web search:" : schedData.source === "website" ? "📅 From their website:" : "📅 Typical weekly schedule:";
    const bg = isFeatured ? "rgba(255,255,255,0.75)" : "#fff";
    return (
      <div style={{ marginTop: 10 }}>
        <p style={{ fontSize: 11, fontWeight: 600, color: "#1D9E75", margin: "0 0 6px" }}>{sourceLabel}</p>
        {filtered.map((e, ei) => (
          <div key={ei} style={{ background: bg, borderRadius: 10, padding: "10px 12px", marginBottom: 6, border: "1px solid #e2e8f0", borderLeft: "3px solid #1D9E75" }}>
            <p style={{ fontWeight: 600, fontSize: 13, margin: "0 0 3px", color: "#0f172a" }}>{e.event || e.band || "Event"}</p>
            <div style={{ display: "flex", flexWrap: "wrap", gap: "3px 12px", fontSize: 11, color: "#64748b" }}>
              {e.day && <span>📆 {e.day}</span>}
              {e.date && <span>📅 {e.date}</span>}
              {e.time && <span>🕐 {e.time}</span>}
              {e.notes && <span>ℹ️ {e.notes}</span>}
            </div>
          </div>
        ))}
      </div>
    );
  };

  const NoScheduleMessage = ({ websiteUrl }) => (
    <div style={{ marginTop: 8, background: "#fff8f0", borderRadius: 10, padding: "10px 12px", border: "1px solid #fed7aa" }}>
      <p style={{ fontSize: 12, color: "#92400e", margin: "0 0 6px" }}>😕 Couldn't find a specific schedule right now.</p>
      {websiteUrl && <a href={websiteUrl} target="_blank" rel="noreferrer" style={{ fontSize: 12, color: "#e85d04", fontWeight: 600, textDecoration: "none" }}>👉 Visit their site to see the current event lineup →</a>}
    </div>
  );

  return (
    <>
      {/* Fixed Branding Bar */}
      <div style={{
        position: "fixed",
        top: 0,
        left: 0,
        right: 0,
        zIndex: 1000,
        background: "linear-gradient(135deg,#e85d04 0%,#c44a00 100%)",
        padding: "10px 20px",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        boxShadow: "0 2px 12px rgba(232,93,4,0.45)",
        overflow: "hidden",
        minHeight: 52,
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <span style={{ fontSize: 22 }}>🎵</span>
          <div>
            <div style={{ fontSize: 15, fontWeight: 700, color: "#fff", lineHeight: 1.1, letterSpacing: "-0.3px", whiteSpace: "nowrap" }}>BBK Music Seeker</div>
            <div style={{ fontSize: 10, color: "rgba(255,255,255,0.8)", letterSpacing: "1.5px", textTransform: "uppercase", marginTop: 1, whiteSpace: "nowrap" }}>Find live music anywhere</div>
          </div>
        </div>
        <div style={{ fontSize: 11, color: "rgba(255,255,255,0.75)", fontStyle: "italic" }}>locallivemusic.ai</div>
      </div>

      <div style={{ height: 52 }} />

      <div style={{ fontFamily: "system-ui,sans-serif", maxWidth: 700, margin: "0 auto", borderRadius: 20, boxShadow: "0 4px 24px rgba(0,0,0,0.12)", overflow: "hidden" }}>

      {/* Hero Image */}
      <div style={{ background: "linear-gradient(135deg,#e85d04 0%,#c44a00 100%)" }}>
        <img src="/hero.png" alt="" style={{ width: "100%", display: "block", objectFit: "cover", objectPosition: "center top", maxHeight: 200 }} />
      </div>

      {/* Search */}
      <div style={{ background: "#fff", padding: "1.25rem 1.5rem 0" }}>
        <div style={{ display: "flex", gap: 8, marginBottom: 8 }}>
          <input value={query} onChange={e => setQuery(e.target.value)} onKeyDown={e => e.key === "Enter" && search()}
            placeholder="Zip code, city, venue, or restaurant…"
            style={{ flex: 1, fontSize: 15, borderRadius: 10, padding: "10px 14px", border: "1px solid #e2e8f0", outline: "none" }} />
          <button onClick={useLocation} title="Use my location"
            style={{ padding: "0 14px", fontSize: 18, borderRadius: 10, border: "1px solid #e2e8f0", background: "#f8fafc", cursor: "pointer" }}>
            {locating ? "⏳" : "📍"}
          </button>
          <button onClick={() => search()} disabled={loading || !query.trim()}
            style={{ padding: "0 18px", fontSize: 15, fontWeight: 500, borderRadius: 10, border: "none", background: loading || !query.trim() ? "#e2e8f0" : "#e85d04", color: loading || !query.trim() ? "#94a3b8" : "#fff", cursor: loading || !query.trim() ? "default" : "pointer" }}>
            {loading ? "…" : "Search"}
          </button>
        </div>
        {results === null && !loading && (
          <div style={{ marginBottom: 10 }}>
            <button
              onClick={() => { document.querySelector("input[placeholder*='Zip code']")?.focus(); }}
              style={{ fontSize: 13, fontWeight: 700, padding: "10px 24px", borderRadius: 99, background: "linear-gradient(135deg,#e85d04,#c44a00)", color: "#fff", border: "none", cursor: "pointer", boxShadow: "0 2px 8px rgba(232,93,4,0.35)", letterSpacing: "0.3px" }}>
              🎵 Start Your Live Music Search
            </button>
          </div>
        )}
        <div style={{ display: "flex", gap: 6, marginBottom: 10 }}>
          {DATE_FILTERS.map(f => (<button key={f} style={btn(dateFilter === f)} onClick={() => setDateFilter(f)}>{f}</button>))}
        </div>
        <div style={{ display: "flex", gap: 6, marginBottom: 10, alignItems: "center" }}>
          <span style={{ fontSize: 11, color: "#94a3b8", whiteSpace: "nowrap" }}>📍 Within:</span>
          {RADIUS_OPTIONS.map(r => (<button key={r} style={btn(radius === r)} onClick={() => setRadius(r)}>{r} mi</button>))}
        </div>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: "1.25rem" }}>
          <div style={{ fontSize: 11, color: "#94a3b8", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 6 }}>
            ⭐ Locations with Featured Venues
          </div>
          {QUICK.filter(sq => quickHasFeaturedVenue(sq)).map(sq => (
            <button key={sq} onClick={() => { setActiveQuick(sq); setQuery(sq); search(sq); }}
              style={{ fontSize: 11, padding: "5px 14px", borderRadius: 99, border: "1.5px solid #e85d04", background: activeQuick === sq ? "#e85d04" : "transparent", color: activeQuick === sq ? "#fff" : "#e85d04", cursor: "pointer", fontWeight: activeQuick === sq ? 600 : 400 }}>
              {sq}
            </button>
          ))}
        </div>

        {/* Band / Artist Search */}
        <div style={{ marginBottom: "1.25rem" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
            <span style={{ fontSize: 11, color: "#94a3b8", whiteSpace: "nowrap", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.5px" }}>🎸 Find a Band or Artist:</span>
            {bandSearch && (
              <button onClick={() => setBandSearch("")}
                style={{ fontSize: 10, padding: "2px 8px", borderRadius: 99, border: "1px solid #e2e8f0", background: "#f1f5f9", color: "#64748b", cursor: "pointer" }}>
                Clear
              </button>
            )}
          </div>
          <div style={{ display: "flex", gap: 8, marginBottom: 8 }}>
            <input
              value={bandSearch}
              onChange={e => setBandSearch(e.target.value)}
              placeholder="e.g. Nathan Carter, The Eagles, local jazz trio…"
              style={{ flex: 1, fontSize: 13, borderRadius: 10, padding: "8px 12px", border: "1px solid #e2e8f0", outline: "none", background: "#f8fafc", color: "#0f172a" }}
            />
          </div>
          {FEATURED_BANDS.length > 0 && (
            <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 6 }}>
              <span style={{ fontSize: 10, color: "#94a3b8", alignSelf: "center" }}>Featured:</span>
              {FEATURED_BANDS.map(b => (
                <button key={b.name}
                  onClick={() => setBandSearch(b.name)}
                  style={{ fontSize: 11, padding: "4px 12px", borderRadius: 99, border: `1.5px solid ${bandSearch === b.name ? "#e85d04" : "#e2e8f0"}`, background: bandSearch === b.name ? "#e85d04" : "#f8fafc", color: bandSearch === b.name ? "#fff" : "#475569", cursor: "pointer", fontWeight: bandSearch === b.name ? 600 : 400 }}>
                  🎵 {b.name} <span style={{ fontSize: 10, opacity: 0.75 }}>({b.genre})</span>
                </button>
              ))}
            </div>
          )}
          <button onClick={() => setShowContactForm(f => !f)}
            style={{ fontSize: 11, color: "#e85d04", background: "none", border: "none", cursor: "pointer", padding: 0, textDecoration: "underline" }}>
            + Get your band listed here
          </button>
          {showContactForm && !contactSent && (
            <div style={{ marginTop: 10, background: "#fff7ed", border: "1px solid #fed7aa", borderRadius: 12, padding: "14px 16px" }}>
              <p style={{ fontSize: 12, fontWeight: 600, color: "#92400e", margin: "0 0 10px" }}>🎶 Submit Your Band</p>
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                <input value={contactName} onChange={e => setContactName(e.target.value)} placeholder="Your name" style={{ fontSize: 12, padding: "7px 10px", borderRadius: 8, border: "1px solid #fed7aa", outline: "none" }} />
                <input value={contactEmail} onChange={e => setContactEmail(e.target.value)} placeholder="Your email" style={{ fontSize: 12, padding: "7px 10px", borderRadius: 8, border: "1px solid #fed7aa", outline: "none" }} />
                <input value={contactBand} onChange={e => setContactBand(e.target.value)} placeholder="Band or artist name" style={{ fontSize: 12, padding: "7px 10px", borderRadius: 8, border: "1px solid #fed7aa", outline: "none" }} />
                <textarea value={contactMsg} onChange={e => setContactMsg(e.target.value)} placeholder="Tell us about your music, genre, where you play…" rows={3} style={{ fontSize: 12, padding: "7px 10px", borderRadius: 8, border: "1px solid #fed7aa", outline: "none", resize: "vertical" }} />
                <button
                  onClick={async () => {
                    if (!contactEmail || !contactBand) return;
                    await fetch("https://formspree.io/f/xnjkzbkl", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ _subject: `Band Listing Request: ${contactBand}`, name: contactName, email: contactEmail, band: contactBand, message: contactMsg }) });
                    setContactSent(true);
                  }}
                  style={{ fontSize: 12, padding: "8px 16px", borderRadius: 8, background: "#e85d04", color: "#fff", border: "none", cursor: "pointer", fontWeight: 600, alignSelf: "flex-start" }}>
                  Send Request
                </button>
              </div>
            </div>
          )}
          {contactSent && (
            <div style={{ marginTop: 10, background: "#f0fdf4", border: "1px solid #bbf7d0", borderRadius: 10, padding: "10px 14px", fontSize: 12, color: "#166534" }}>
              ✅ Thanks! We'll be in touch to get your band listed.
            </div>
          )}

          {/* Venue Request */}
          <div style={{ marginTop: 8 }}>
            <button onClick={() => setShowVenueForm(f => !f)}
              style={{ fontSize: 11, color: "#0369a1", background: "none", border: "none", cursor: "pointer", padding: 0, textDecoration: "underline" }}>
              + Request a venue to be added
            </button>
            {showVenueForm && !venueSent && (
              <div style={{ marginTop: 10, background: "#eff6ff", border: "1px solid #bfdbfe", borderRadius: 12, padding: "14px 16px" }}>
                <p style={{ fontSize: 12, fontWeight: 600, color: "#1e3a5f", margin: "0 0 10px" }}>🏛️ Submit a Venue</p>
                <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                  <input value={venueName} onChange={e => setVenueName(e.target.value)} placeholder="Venue name" style={{ fontSize: 12, padding: "7px 10px", borderRadius: 8, border: "1px solid #bfdbfe", outline: "none" }} />
                  <input value={venueAddress} onChange={e => setVenueAddress(e.target.value)} placeholder="Address" style={{ fontSize: 12, padding: "7px 10px", borderRadius: 8, border: "1px solid #bfdbfe", outline: "none" }} />
                  <input value={venueWebsite} onChange={e => setVenueWebsite(e.target.value)} placeholder="Website or social media URL" style={{ fontSize: 12, padding: "7px 10px", borderRadius: 8, border: "1px solid #bfdbfe", outline: "none" }} />
                  <input value={venueContactName} onChange={e => setVenueContactName(e.target.value)} placeholder="Your name" style={{ fontSize: 12, padding: "7px 10px", borderRadius: 8, border: "1px solid #bfdbfe", outline: "none" }} />
                  <input value={venueContactEmail} onChange={e => setVenueContactEmail(e.target.value)} placeholder="Your email" style={{ fontSize: 12, padding: "7px 10px", borderRadius: 8, border: "1px solid #bfdbfe", outline: "none" }} />
                  <textarea value={venueMsg} onChange={e => setVenueMsg(e.target.value)} placeholder="Tell us about the venue — music genres, nights, vibe…" rows={3} style={{ fontSize: 12, padding: "7px 10px", borderRadius: 8, border: "1px solid #bfdbfe", outline: "none", resize: "vertical" }} />
                  <button
                    onClick={async () => {
                      if (!venueContactEmail || !venueName) return;
                      await fetch("https://formspree.io/f/xnjkzbkl", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ _subject: `Venue Listing Request: ${venueName}`, venue: venueName, address: venueAddress, website: venueWebsite, name: venueContactName, email: venueContactEmail, message: venueMsg }) });
                      setVenueSent(true);
                    }}
                    style={{ fontSize: 12, padding: "8px 16px", borderRadius: 8, background: "#0369a1", color: "#fff", border: "none", cursor: "pointer", fontWeight: 600, alignSelf: "flex-start" }}>
                    Send Request
                  </button>
                </div>
              </div>
            )}
            {venueSent && (
              <div style={{ marginTop: 10, background: "#f0fdf4", border: "1px solid #bbf7d0", borderRadius: 10, padding: "10px 14px", fontSize: 12, color: "#166534" }}>
                ✅ Thanks! We'll look into adding this venue.
              </div>
            )}
          </div>
        </div>

        {/* Culture / Genre Filter */}
        <div style={{ marginBottom: "1.25rem" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
            <span style={{ fontSize: 11, color: "#94a3b8", whiteSpace: "nowrap", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.5px" }}>🌍 Cultural Style:</span>
            {cultures.length > 0 && (
              <button onClick={() => setCultures([])}
                style={{ fontSize: 10, padding: "2px 8px", borderRadius: 99, border: "1px solid #e2e8f0", background: "#f1f5f9", color: "#64748b", cursor: "pointer" }}>
                Clear
              </button>
            )}
          </div>
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
            {CULTURES.map(c => {
              const active = cultures.includes(c.value);
              return (
                <button key={c.value}
                  onClick={() => setCultures(prev => active ? prev.filter(x => x !== c.value) : [...prev, c.value])}
                  style={{ fontSize: 11, padding: "5px 12px", borderRadius: 99, border: `1.5px solid ${active ? "#7c3aed" : "#e2e8f0"}`, background: active ? "#7c3aed" : "#f8fafc", color: active ? "#fff" : "#475569", cursor: "pointer", fontWeight: active ? 600 : 400, transition: "all 0.15s" }}>
                  {c.label}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* SEO Content Section — visible only on idle homepage, hidden after search */}
      {results === null && !loading && (
        <div style={{ background: "#fff", padding: "0 1.5rem 1.5rem", borderTop: "1px solid #f1f5f9" }}>

          {/* Intro */}
          <div style={{ marginBottom: 24, paddingTop: "1.25rem" }}>

            <h2 style={{ fontSize: 16, fontWeight: 700, color: "#0f172a", margin: "0 0 8px" }}>Find Live Music Near You — Tonight or Any Night</h2>
            <p style={{ fontSize: 13, color: "#475569", lineHeight: 1.7, margin: "0 0 16px" }}>
              BBK Music Seeker helps you discover live music events at bars, restaurants, clubs, and venues in your neighborhood.
              Whether you're looking for jazz on a Tuesday, a cover band this weekend, or acoustic sets at a local restaurant —
              just enter your zip code or city and we'll find what's playing near you. Looking for your favorite band on tour?
              Search by artist name and find every show near you. Into Irish, Latin, Afrobeat, or Klezmer? Use our Cultural Style
              filter to surface the venues and events that match your roots. We cover hundreds of cities across the US —
              from Philadelphia and Chicago to Los Angeles and everywhere in between.
            </p>
            <button
              onClick={() => setShowVenueForm(f => !f)}
              style={{ fontSize: 12, fontWeight: 600, padding: "8px 18px", borderRadius: 99, background: "#eff6ff", color: "#0369a1", border: "1.5px solid #bfdbfe", cursor: "pointer", letterSpacing: "0.2px" }}>
              🏛️ Get Your Venue Listed
            </button>
            {showVenueForm && !venueSent && (
              <div style={{ marginTop: 12, background: "#eff6ff", border: "1px solid #bfdbfe", borderRadius: 12, padding: "14px 16px" }}>
                <p style={{ fontSize: 12, fontWeight: 600, color: "#1e3a5f", margin: "0 0 10px" }}>🏛️ Submit a Venue</p>
                <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                  <input value={venueName} onChange={e => setVenueName(e.target.value)} placeholder="Venue name" style={{ fontSize: 12, padding: "7px 10px", borderRadius: 8, border: "1px solid #bfdbfe", outline: "none" }} />
                  <input value={venueAddress} onChange={e => setVenueAddress(e.target.value)} placeholder="Address" style={{ fontSize: 12, padding: "7px 10px", borderRadius: 8, border: "1px solid #bfdbfe", outline: "none" }} />
                  <input value={venueWebsite} onChange={e => setVenueWebsite(e.target.value)} placeholder="Website or social media URL" style={{ fontSize: 12, padding: "7px 10px", borderRadius: 8, border: "1px solid #bfdbfe", outline: "none" }} />
                  <input value={venueContactName} onChange={e => setVenueContactName(e.target.value)} placeholder="Your name" style={{ fontSize: 12, padding: "7px 10px", borderRadius: 8, border: "1px solid #bfdbfe", outline: "none" }} />
                  <input value={venueContactEmail} onChange={e => setVenueContactEmail(e.target.value)} placeholder="Your email" style={{ fontSize: 12, padding: "7px 10px", borderRadius: 8, border: "1px solid #bfdbfe", outline: "none" }} />
                  <textarea value={venueMsg} onChange={e => setVenueMsg(e.target.value)} placeholder="Tell us about the venue — music genres, nights, vibe…" rows={3} style={{ fontSize: 12, padding: "7px 10px", borderRadius: 8, border: "1px solid #bfdbfe", outline: "none", resize: "vertical" }} />
                  <button
                    onClick={async () => {
                      if (!venueContactEmail || !venueName) return;
                      await fetch("https://formspree.io/f/xnjkzbkl", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ _subject: `Venue Listing Request: ${venueName}`, venue: venueName, address: venueAddress, website: venueWebsite, name: venueContactName, email: venueContactEmail, message: venueMsg }) });
                      setVenueSent(true);
                    }}
                    style={{ fontSize: 12, padding: "8px 16px", borderRadius: 8, background: "#0369a1", color: "#fff", border: "none", cursor: "pointer", fontWeight: 600, alignSelf: "flex-start" }}>
                    Send Request
                  </button>
                </div>
              </div>
            )}
            {venueSent && (
              <div style={{ marginTop: 10, background: "#f0fdf4", border: "1px solid #bbf7d0", borderRadius: 10, padding: "10px 14px", fontSize: 12, color: "#166534" }}>
                ✅ Thanks! We'll look into adding this venue.
              </div>
            )}
          </div>

          {/* How It Works */}
          <div style={{ marginBottom: 24 }}>
            <h2 style={{ fontSize: 14, fontWeight: 700, color: "#e85d04", textTransform: "uppercase", letterSpacing: "1px", margin: "0 0 12px" }}>How It Works</h2>
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {[
                { icon: "📍", title: "Enter your location", desc: "Type a zip code, city name, neighborhood, venue, or restaurant — or tap the pin icon to use your current location." },
                { icon: "🗓", title: "Pick your timeframe", desc: "Filter results by today, this weekend, or the next 7 days so you only see events that fit your schedule." },
                { icon: "🎵", title: "Discover live music", desc: "We search local venue websites, event listings, and live databases to surface the best live music options near you, ranked by likelihood." },
                { icon: "🔥", title: "Check the vibe", desc: "See real-time crowd reports from other users so you know what the atmosphere is like before you show up." },
              ].map((step, i) => (
                <div key={i} style={{ display: "flex", gap: 12, alignItems: "flex-start", background: "#f8fafc", borderRadius: 12, padding: "12px 14px", border: "1px solid #e2e8f0" }}>
                  <span style={{ fontSize: 20, flexShrink: 0 }}>{step.icon}</span>
                  <div>
                    <p style={{ fontSize: 13, fontWeight: 600, color: "#0f172a", margin: "0 0 2px" }}>{step.title}</p>
                    <p style={{ fontSize: 12, color: "#64748b", margin: 0, lineHeight: 1.5 }}>{step.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Popular Cities */}
          <div style={{ marginBottom: 24 }}>
            <h2 style={{ fontSize: 14, fontWeight: 700, color: "#e85d04", textTransform: "uppercase", letterSpacing: "1px", margin: "0 0 12px" }}>Popular Cities for Live Music</h2>
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {[
                { city: "Philadelphia, PA", desc: "Philly has one of the most vibrant live music scenes on the East Coast. From the dive bars of South Street to intimate jazz clubs in Old City and rock venues in Fishtown, there's live music happening every night of the week." },
                { city: "West Chester, PA", desc: "West Chester's walkable downtown is packed with bars and restaurants featuring live music Wednesday through Saturday. Station 142, Pietro's Prime, and Slow Hand are local favorites with regular live entertainment." },
                { city: "Chicago, IL", desc: "Chicago is the birthplace of electric blues and home to world-class jazz clubs, rock venues, and everything in between. The city's live music scene spans neighborhoods from Lincoln Park to Wicker Park to the South Side." },
                { city: "Los Angeles, CA", desc: "LA's live music scene is unmatched on the West Coast — from legendary venues like the Troubadour and the Roxy to rooftop bars in Silver Lake and intimate acoustic sets in Santa Monica restaurants." },
                { city: "Sea Isle City, NJ", desc: "Sea Isle is a Jersey Shore destination with a thriving summer live music scene. Local bars and restaurants book bands and solo artists throughout the summer season, making it a favorite for beach visitors looking for nightlife." },
                { city: "Miami, FL", desc: "Miami's live music scene pulses with Latin rhythms, jazz, hip-hop, and electronic beats. From the clubs of Wynwood and Little Havana to rooftop bars in South Beach and intimate venues in Coral Gables, the city never stops moving." },
                { city: "Dallas, TX", desc: "Dallas has a thriving live music culture rooted in country, blues, and Texas rock. Deep Ellum is the city's legendary music district, packed with clubs and venues that have launched countless careers and keep the scene alive every night." },
                { city: "Seattle, WA", desc: "Seattle's music legacy — from grunge to indie to jazz — lives on in hundreds of clubs, bars, and listening rooms across Capitol Hill, Ballard, and Belltown. Rain or shine, Seattle's live music scene is one of the most passionate in the country." },
              ].map((item, i) => (
                <div key={i} style={{ borderRadius: 12, padding: "12px 14px", border: "1px solid #e2e8f0", borderLeft: "4px solid #e85d04", background: "#fff" }}>
                  <p style={{ fontSize: 13, fontWeight: 700, color: "#0f172a", margin: "0 0 4px" }}>{item.city}</p>
                  <p style={{ fontSize: 12, color: "#64748b", margin: 0, lineHeight: 1.6 }}>{item.desc}</p>
                </div>
              ))}
            </div>
          </div>

          {/* About */}
          <div style={{ background: "#fff8f0", borderRadius: 14, padding: "16px 18px", border: "1px solid #fed7aa" }}>
            <h2 style={{ fontSize: 14, fontWeight: 700, color: "#92400e", margin: "0 0 8px" }}>About BBK Music Seeker</h2>
            <p style={{ fontSize: 12, color: "#78350f", lineHeight: 1.7, margin: 0 }}>
              BBK Music Seeker is a free live music discovery tool powered by AI. We aggregate event information from venue websites,
              social media, and public event databases to help music fans find great live performances near them.
              Our goal is simple: no more googling five different sites to find out what's playing tonight.
              Just search your location and get results in seconds. We cover bars, restaurants, clubs, breweries, amphitheaters,
              and any venue that hosts live music — from small local acts to regional touring artists.
            </p>
          </div>

        </div>
      )}

      {/* Results */}
      <div style={{ background: "#fff", padding: "0 1.5rem 1.5rem", minHeight: 80 }}>
        {error && <div style={{ background: "#fee2e2", border: "0.5px solid #fca5a5", borderRadius: 10, padding: "10px 14px", fontSize: 13, color: "#dc2626", marginBottom: 12 }}>{error}</div>}
        {loading && (
          <div style={{ textAlign: "center", padding: "2rem 0", color: "#64748b" }}>
            <div style={{ fontSize: 28, marginBottom: 8 }}>🎵</div>
            <div style={{ fontSize: 14, fontWeight: 500 }}>Finding live music near <em>{searched}</em>…</div>
          </div>
        )}

        {results !== null && !loading && (
          <>
            {/* Featured Venues */}
            {showFeatured && (
              <div style={{ marginBottom: 16 }}>
                <p style={{ fontSize: 11, fontWeight: 600, color: "#e85d04", textTransform: "uppercase", letterSpacing: "1px", margin: "0 0 8px" }}>⭐ Featured Venues</p>
                <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
                  {FEATURED_VENUES.filter(v => {
                    const sl = searched.toLowerCase(), al = v.address.toLowerCase();
                    if (sl.includes("19382") || sl.includes("west chester") || sl.includes("westchester")) return al.includes("19382") || al.includes("west chester");
                    if (sl.includes("18347") || sl.includes("pocono lake")) return al.includes("18347") || al.includes("pocono lake");
                    if (sl.includes("chicago")) return al.toLowerCase().includes("chicago");
                    if (v.name === "Commodore John Barry Arts & Cultural Center") return cultures.includes("Irish and Celtic") || sl.includes("19119") || sl.includes("philadelphia") || sl.includes("mt. airy") || sl.includes("mt airy");
                    return false;
                  }).map((v, i) => {
                    const key = v.website || v.name;
                    const isLoadingSched = loadingSchedule === key;
                    const schedData = venueSchedules[key];
                    const hasPerformerData = schedData && (schedData.source === "web_search" || schedData.source === "website");
                    return (
                      <div key={i} style={{ flex: "1 1 260px", background: `linear-gradient(135deg,${v.color}22,${v.color}08)`, border: `1.5px solid ${v.color}44`, borderRadius: 14, padding: "14px 16px" }}>
                        <p style={{ fontWeight: 700, fontSize: 15, margin: "0 0 4px", color: "#0f172a" }}>{v.name}</p>
                        <span style={{ fontSize: 11, padding: "2px 8px", borderRadius: 99, background: v.color + "22", color: v.color, fontWeight: 600 }}>{v.tag}</span>
                        <p style={{ fontSize: 12, color: "#64748b", margin: "8px 0", lineHeight: 1.5 }}>{v.description}</p>
                        <p style={{ fontSize: 11, color: "#94a3b8", margin: "0 0 10px" }}>📍 {v.address}</p>
                        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 10 }}>
                          {!hasPerformerData && (
                            <button onClick={() => findPerformers(v)} disabled={isLoadingSched}
                              style={{ fontSize: 12, padding: "6px 14px", borderRadius: 99, background: isLoadingSched ? "#e2e8f0" : "#1D9E75", color: isLoadingSched ? "#94a3b8" : "#fff", border: "none", cursor: isLoadingSched ? "default" : "pointer", fontWeight: 500 }}>
                              {isLoadingSched ? "🔍 Searching…" : "🔍 Find This Week's Performers"}
                            </button>
                          )}
                          <a href={v.website} target="_blank" rel="noreferrer"
                            style={{ fontSize: 12, padding: "6px 14px", borderRadius: 99, background: v.color, color: "#fff", textDecoration: "none", fontWeight: 500 }}>
                            🌍 Visit Site
                          </a>
                          {v.openTable && (
                            <a href={withUTM(v.openTable, v.name)} target="_blank" rel="noreferrer"
                              onClick={() => trackReserve(v.name)}
                              style={{ fontSize: 12, padding: "6px 14px", borderRadius: 99, background: "#f1f5f9", color: "#e85d04", textDecoration: "none", border: "0.5px solid #e2e8f0", fontWeight: 500 }}>
                              🍽 Reserve
                            </a>
                          )}
                        </div>
                        <ScheduleBlock schedData={schedData} isLoading={isLoadingSched} websiteUrl={v.scheduleUrl} isFeatured={true} />
                        {hasPerformerData === false && schedData && schedData.schedule.length === 0 && <NoScheduleMessage websiteUrl={v.scheduleUrl} />}
                        <VibeSection venueName={v.name} allVibes={allVibes} instagram={v.instagram} />
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* AI Results */}
            {results.length > 0 && (
              <>
                <p style={{ fontSize: 11, fontWeight: 600, color: "#64748b", textTransform: "uppercase", letterSpacing: "1px", margin: "0 0 8px" }}>
                  {showFeatured ? "🎸 More Live Music Nearby" : "🎸 Live Music Events"}
                </p>
                <div style={{ background: "#fff8f0", border: "1px solid #fed7aa", borderRadius: 10, padding: "10px 14px", marginBottom: 12, fontSize: 12, color: "#92400e" }}>
                  ⚠️ <strong>Always verify before you go</strong> — AI results may not be accurate.
                  <div style={{ display: "flex", gap: 8, marginTop: 6, flexWrap: "wrap" }}>
                    <a href={`https://www.songkick.com/metro-areas/search?query=${encodeURIComponent(searched)}`} target="_blank" rel="noreferrer" style={{ fontSize: 11, padding: "3px 10px", borderRadius: 99, background: "#f97316", color: "#fff", textDecoration: "none" }}>🎵 Songkick</a>
                    <a href={`https://www.bandsintown.com/search?query=${encodeURIComponent(searched)}`} target="_blank" rel="noreferrer" style={{ fontSize: 11, padding: "3px 10px", borderRadius: 99, background: "#16a34a", color: "#fff", textDecoration: "none" }}>🎸 Bandsintown</a>
                    <a href={`https://www.google.com/search?q=live+music+${encodeURIComponent(searched)}+this+weekend`} target="_blank" rel="noreferrer" style={{ fontSize: 11, padding: "3px 10px", borderRadius: 99, background: "#3b82f6", color: "#fff", textDecoration: "none" }}>🔍 Google</a>
                  </div>
                </div>
                {results.map((r, i) => (
                  <div key={i} style={{ background: "#f8fafc", borderRadius: 14, overflow: "hidden", borderLeft: `4px solid ${gc(r.genre)}`, marginBottom: 10 }}>
                    <div style={{ padding: "14px 16px" }}>
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 8, marginBottom: 6 }}>
                        <div>
                          <p style={{ fontWeight: 600, fontSize: 15, margin: "0 0 2px", color: "#0f172a" }}>{r.band}</p>
                          <p style={{ fontSize: 13, color: "#64748b", margin: 0 }}>{r.venue}</p>
                        </div>
                        <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 4 }}>
                          {r.genre && <span style={{ fontSize: 10, padding: "3px 10px", borderRadius: 99, background: gc(r.genre) + "22", color: gc(r.genre), fontWeight: 600 }}>{r.genre}</span>}
                          {r.confidence === "medium" && <span style={{ fontSize: 9, padding: "2px 8px", borderRadius: 99, background: "#fef9c3", color: "#854d0e", fontWeight: 600 }}>⚠️ Unverified</span>}
                        </div>
                      </div>
                      <div style={{ display: "flex", flexWrap: "wrap", gap: "4px 16px", fontSize: 12, color: "#64748b", marginBottom: 8 }}>
                        {r.date && <span>📅 {r.date}</span>}
                        {r.time && <span>🕐 {r.time}</span>}
                        {r.address && <span>📍 {r.address}</span>}
                        {r.notes && <span>ℹ️ {r.notes}</span>}
                        {r.tickets && r.tickets.startsWith("http") ? <a href={r.tickets} target="_blank" rel="noreferrer" style={{ color: "#e85d04", fontWeight: 500 }}>🎟 Tickets</a> : r.tickets ? <span>🎟 {r.tickets}</span> : null}
                      </div>
                      <button style={{ fontSize: 12, color: "#e85d04", background: "transparent", border: "none", cursor: "pointer", padding: 0, fontWeight: 500 }} onClick={() => setExpanded(expanded === i ? null : i)}>
                        {expanded === i ? "▲ Hide details" : "▼ Show venue & artist info"}
                      </button>
                    </div>
                    {expanded === i && (
                      <div style={{ borderTop: "1px solid #e2e8f0", padding: "14px 16px", background: "#fff" }}>
                        {r.venueBio && <div style={{ marginBottom: 10 }}><p style={{ fontSize: 12, fontWeight: 600, color: "#e85d04", margin: "0 0 4px", textTransform: "uppercase" }}>🏠 About the Venue</p><p style={{ fontSize: 13, color: "#64748b", margin: 0, lineHeight: 1.5 }}>{r.venueBio}</p></div>}
                        {r.bandBio && r.bandBio.length > 10 && <div style={{ marginBottom: 10 }}><p style={{ fontSize: 12, fontWeight: 600, color: "#e85d04", margin: "0 0 4px", textTransform: "uppercase" }}>🎤 About the Artist</p><p style={{ fontSize: 13, color: "#64748b", margin: 0, lineHeight: 1.5 }}>{r.bandBio}</p></div>}
                        <div style={{ borderTop: "1px solid #f1f5f9", paddingTop: 10 }}>
                          <p style={{ fontSize: 12, fontWeight: 600, color: "#e85d04", margin: "0 0 6px", textTransform: "uppercase" }}>🔍 Verify this event</p>
                          <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                            <a href={`https://www.google.com/search?q=${encodeURIComponent((r.band || "") + " " + (r.venue || ""))}`} target="_blank" rel="noreferrer" style={{ fontSize: 11, padding: "4px 10px", borderRadius: 99, background: "#3b82f6", color: "#fff", textDecoration: "none" }}>🔍 Google</a>
                            <a href={`https://www.songkick.com/search?query=${encodeURIComponent(r.band || "")}`} target="_blank" rel="noreferrer" style={{ fontSize: 11, padding: "4px 10px", borderRadius: 99, background: "#f97316", color: "#fff", textDecoration: "none" }}>🎵 Songkick</a>
                            <a href={`https://www.bandsintown.com/search?query=${encodeURIComponent(r.band || "")}`} target="_blank" rel="noreferrer" style={{ fontSize: 11, padding: "4px 10px", borderRadius: 99, background: "#16a34a", color: "#fff", textDecoration: "none" }}>🎸 Bandsintown</a>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </>
            )}
          </>
        )}
      </div>

      {/* Nearby Bars & Restaurants */}
      {(localLoading || localVenues !== null || localError) && (
        <div style={{ background: "#fff", borderTop: "1px solid #e2e8f0", padding: "1.25rem 1.5rem" }}>
          {/* AdSense ad unit */}
          <div style={{ marginBottom: 16, textAlign: "center", background: "#f8fafc", borderRadius: 10, overflow: "hidden", border: "1px solid #e2e8f0", padding: "4px 0" }}>
            <p style={{ fontSize: 9, color: "#94a3b8", margin: "0 0 2px", textTransform: "uppercase", letterSpacing: "1px" }}>Advertisement</p>
            <ins className="adsbygoogle"
              style={{ display: "block" }}
              data-ad-client="ca-pub-5006125305468777"
              data-ad-slot="auto"
              data-ad-format="auto"
              data-full-width-responsive="true" />
          </div>
          <p style={{ fontSize: 12, fontWeight: 600, color: "#e85d04", textTransform: "uppercase", letterSpacing: "1px", margin: "0 0 8px" }}>🍺 Nearby Bars & Restaurants</p>
          {localLoading && <div style={{ fontSize: 13, color: "#64748b", padding: "8px 0" }}>🔍 Finding venues near {searched}…</div>}
          {localError && <div style={{ fontSize: 12, color: "#dc2626" }}>{localError}</div>}
          {localVenues !== null && !localLoading && (
            localVenues.length === 0
              ? <p style={{ fontSize: 13, color: "#64748b" }}>No venues found nearby.</p>
              : <>
                <p style={{ fontSize: 11, color: "#94a3b8", margin: "0 0 10px" }}>Found {localVenues.length} venues • Sorted by music likelihood</p>
                {localVenues.map((v, vi) => {
                  const sc = v.musicScore === "high" ? "#16a34a" : v.musicScore === "medium" ? "#d97706" : "#94a3b8";
                  const sl = v.musicScore === "high" ? "🎵 Likely has music" : v.musicScore === "medium" ? "🎲 Possible music" : "🍽 Unknown";
                  const schedKey = v.website || v.name;
                  const schedData = venueSchedules[schedKey];
                  const isLoadingSched = loadingSchedule === schedKey;
                  const hasPerformerData = schedData && (schedData.source === "web_search" || schedData.source === "website");
                  const otLink = `https://www.opentable.com/s?term=${encodeURIComponent(v.name)}&covers=2`;
                  return (
                    <div key={vi} style={{ background: "#f8fafc", borderRadius: 14, padding: "14px 16px", marginBottom: 10, border: "1px solid #e2e8f0", borderLeft: `4px solid ${sc}` }}>
                      <div style={{ marginBottom: 8 }}>
                        <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap", marginBottom: 4 }}>
                          <p style={{ fontWeight: 700, fontSize: 15, margin: 0, color: "#0f172a" }}>{v.name}</p>
                          <span style={{ fontSize: 10, padding: "2px 8px", borderRadius: 99, background: sc + "22", color: sc, fontWeight: 600 }}>{sl}</span>
                          {v.isOpen === true && <span style={{ fontSize: 10, padding: "2px 8px", borderRadius: 99, background: "#dcfce7", color: "#16a34a", fontWeight: 600 }}>Open Now</span>}
                          {v.isOpen === false && <span style={{ fontSize: 10, padding: "2px 8px", borderRadius: 99, background: "#fee2e2", color: "#dc2626", fontWeight: 600 }}>Closed</span>}
                        </div>
                        <p style={{ fontSize: 11, color: "#94a3b8", margin: "0 0 2px" }}>📍 {v.address}</p>
                        {v.rating && <p style={{ fontSize: 11, color: "#94a3b8", margin: "0 0 4px" }}>⭐ {v.rating} ({(v.totalRatings || 0).toLocaleString()} reviews)</p>}
                        {v.summary && <p style={{ fontSize: 12, color: "#64748b", margin: 0, lineHeight: 1.5, fontStyle: "italic" }}>{v.summary}</p>}
                      </div>
                      {v.photos && v.photos.length > 0 && (
                        <div style={{ display: "flex", gap: 6, marginBottom: 10, overflowX: "auto" }}>
                          {v.photos.map((src, pi) => (
                            <img key={pi} src={src} alt={v.name} style={{ height: 90, width: 130, objectFit: "cover", borderRadius: 8, flexShrink: 0, border: "1px solid #e2e8f0" }} />
                          ))}
                        </div>
                      )}
                      <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 8 }}>
                        {!hasPerformerData && (
                          <button onClick={() => findPerformers(v)} disabled={isLoadingSched}
                            style={{ fontSize: 11, padding: "5px 12px", borderRadius: 99, background: isLoadingSched ? "#e2e8f0" : "#1D9E75", color: isLoadingSched ? "#94a3b8" : "#fff", border: "none", cursor: isLoadingSched ? "default" : "pointer", fontWeight: 500 }}>
                            {isLoadingSched ? "🔍 Searching…" : "🔍 Find This Week's Performers"}
                          </button>
                        )}
                        <a href={withUTM(otLink, v.name)} target="_blank" rel="noreferrer" onClick={() => trackReserve(v.name)} style={{ fontSize: 11, padding: "5px 12px", borderRadius: 99, background: "#fff0e8", color: "#e85d04", textDecoration: "none", border: "0.5px solid #fed7aa", fontWeight: 500 }}>🍽 Reserve</a>
                        <a href={`https://www.google.com/search?q=${encodeURIComponent(v.name + " " + v.address + " live music events")}`} target="_blank" rel="noreferrer" style={{ fontSize: 11, padding: "5px 12px", borderRadius: 99, background: "#f1f5f9", color: "#64748b", textDecoration: "none", border: "0.5px solid #e2e8f0" }}>🌐 Search Events</a>
                        {v.website && <a href={v.website} target="_blank" rel="noreferrer" style={{ fontSize: 11, padding: "5px 12px", borderRadius: 99, background: "#f1f5f9", color: "#64748b", textDecoration: "none", border: "0.5px solid #e2e8f0" }}>🌍 Visit Site</a>}
                        {v.instagram && <a href={v.instagram} target="_blank" rel="noreferrer" style={{ fontSize: 11, padding: "5px 12px", borderRadius: 99, background: "#f1f5f9", color: "#c026d3", textDecoration: "none", border: "0.5px solid #e2e8f0" }}>📸 Instagram</a>}
                        {v.facebook && <a href={v.facebook} target="_blank" rel="noreferrer" style={{ fontSize: 11, padding: "5px 12px", borderRadius: 99, background: "#f1f5f9", color: "#1d4ed8", textDecoration: "none", border: "0.5px solid #e2e8f0" }}>👍 Facebook</a>}
                      </div>
                      <ScheduleBlock schedData={schedData} isLoading={isLoadingSched} websiteUrl={v.website} isFeatured={false} />
                      {hasPerformerData === false && schedData && schedData.schedule.length === 0 && <NoScheduleMessage websiteUrl={v.website} />}
                      <VibeSection venueName={v.name} allVibes={allVibes} instagram={v.instagram || null} />
                    </div>
                  );
                })}
              </>
          )}
        </div>
      )}
    </div>
    </>
  );
}
